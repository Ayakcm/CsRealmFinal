from django.urls import path,include
from . import views
urlpatterns = [
    path('',views.home,name='home'),
    path('Login/',views.user_auth,name="login"),
    path('Logout/',views.user_logout,name="logout"),
    path('Course/<str:pk>/',views.Enter_course,name="course"),
    path('like_course/<str:pk>/',views.like_course,name="like_course"),
    path('dislike_course/<str:pk>/',views.dislike_course,name="dislike_course"),
]