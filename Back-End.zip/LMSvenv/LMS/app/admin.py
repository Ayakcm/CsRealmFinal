from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(StudentUser)
admin.site.register(Video)
admin.site.register(Playlist)
admin.site.register(Comment)
admin.site.register(Course)