from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login,logout
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from .models import Course
from django.http import HttpResponseRedirect
from django.urls import reverse

# Create your views here.
def home(reqeust):
    courses = Course.objects.all()
    counter = Course.objects.all().count()
    context = {
        'course':courses,
        'count' : counter
    }
    return render(reqeust,'pages/home.html',context)

def user_auth(request):
    if request.method == 'POST':
        if 'sign_up' in request.POST:
            first_name = request.POST.get('first_name')
            last_name = request.POST.get('last_name')
            email = request.POST.get('email')
            password = request.POST.get('password')
            print("signup")
            if not User.objects.filter(username=email).exists():
                user = User.objects.create(
                    first_name=first_name,
                    last_name=last_name,
                    email=email,
                    username=email,
                    password=make_password(password)
                )
                login(request, user)
                return redirect('home')
            else:
                error_message = "Email is already registered."
                return render(request, 'auth/login.html', {'error_message': error_message})

        elif 'sign_in' in request.POST:
            username = request.POST.get('username')
            password = request.POST.get('password')
            print("signin")
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                error_message = "Invalid login credentials."
                return render(request, 'auth/login.html', {'error_message': error_message})
    
    return render(request, 'auth/login.html')

def user_logout(request):
    logout(request)
    return redirect('home') 

def Enter_course(request,pk):
    course = Course.objects.get(id=pk)
    count_video = course.playlist.videos.count()
    count_comment = course.comment.count()
    context = {
        'course':course,
        'count_video':count_video,
        'count_comment':count_comment
    }
    return render(request,'pages/videos.html',context)

def like_course(request,pk):
    course = Course.objects.get(id=pk)
    if request.user not in course.Likers.all() and request.user in course.Dislikers.all():
        course.Likers.add(request.user)
        course.Dislikers.remove(request.user)
        return redirect('course',pk=pk)
    elif request.user not in course.Likers.all():
        course.Likers.add(request.user)
        return redirect('course',pk=pk)
    else:
        course.Likers.remove(request.user)
        return redirect('course',pk=pk)
    

def dislike_course(request, pk):
    course = Course.objects.get(id=pk)
    if request.user not in course.Dislikers.all() and request.user in course.Likers.all():
        course.Dislikers.add(request.user)
        course.Likers.remove(request.user)
        return redirect('course', pk=pk)
    elif request.user not in course.Dislikers.all():
        course.Dislikers.add(request.user)
        return redirect('course', pk=pk)
    else:
        course.Dislikers.remove(request.user)
        return redirect('course', pk=pk)