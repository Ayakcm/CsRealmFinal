from django.db import models
from django.contrib.auth.models import User

class StudentUser(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    
    def __str__(self):
        return self.user.username



class Video(models.Model):
    playlist = models.ForeignKey('Playlist', on_delete=models.CASCADE, related_name='playlist_videos')  # Changed related_name
    video_file = models.FileField(upload_to='videos/')  # Added FileField for video
    
class Playlist(models.Model):
    name = models.CharField(max_length=100)
    videos = models.ManyToManyField('Video', related_name='playlists',blank=True)  # Changed related_name 
    def __str__(self):
        return self.name

class Comment(models.Model):
    comment = models.CharField(max_length=50)
    
class Course(models.Model):
    Title = models.CharField(max_length=50)
    picture = models.ImageField(upload_to='Course_picture', null=True)
    playlist = models.OneToOneField(Playlist, on_delete=models.CASCADE,blank=True,null=True)
    Likers = models.ManyToManyField(User, related_name='liked_courses',blank=True)  # Changed related_name
    Dislikers = models.ManyToManyField(User, related_name='disliked_courses',blank=True)  # Changed related_name
    comment = models.ManyToManyField(Comment,blank=True)
